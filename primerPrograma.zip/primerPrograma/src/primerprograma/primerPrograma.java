package primerprograma;

public class primerPrograma {
        public static void main(String[] args) {
        System.out.println("Hola Mundo");
        System.out.println("Alejandro");

        //Variable y constante en java

        String estudiante = "Pepito";
        int age = 35;
        float score1 = 4.6f;
        double scoreFinal = 4.1d;
        long documento = 21342232823l;
        short clave = 1234;
        final float GRAVEDAD = 9.8f; //constante
        boolean esMayorEdad = true;
        System.out.println("Nombre Estudiante: "+estudiante);
        System.out.println("Edad Estudiante: "+age);
        System.out.println("Nota Estudiante: "+score1);
        System.out.println("Documento Estudiante: "+documento);
        System.out.println("Gravedad: "+GRAVEDAD);
        System.out.println("Clave Estudiante: "+clave);
        if (esMayorEdad == true){
                System.out.println("Es mayor de edad: Verdadero");
        }else{
                System.out.println("Es mayor de edad: Falso");
        }
}
}
