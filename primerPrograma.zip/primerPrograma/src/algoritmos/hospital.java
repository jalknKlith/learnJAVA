package algoritmos;

import java.util.Scanner;

public class PresupuestoHospital {

    public static void main(String[] args) {
	// En un hospital existen tres áreas: Ginecología, Pediatría, 
	// Traumatología.
	// ... Elpresupuesto anual del hospital se reparte 40% Ginecologia, 
	// 30% Pediatria, 30% Traumologia,
	// Leer el presupuesto total
	// e imprimir el valor del presupuesto por área.	
        // Leer el presupuesto total
        Scanner scanner = new Scanner(System.in);
        System.out.print("Ingrese el presupuesto total anual del hospital: ");
        double presupuestoTotal = scanner.nextDouble();

	// Calcular el presupuesto por área
        double ginecologia = Math.round(presupuestoTotal * 0.4 * 100) / 100.0;
        double pediatria = Math.round(presupuestoTotal * 0.3 * 100) / 100.0;
        double traumatologia = Math.round(presupuestoTotal * 0.3 * 100) / 100.0;

        // Imprimir el presupuesto por área
        System.out.println("Presupuesto para Ginecología: " + ginecologia);
        System.out.println("Presupuesto para Pediatría: " + pediatria);
        System.out.println("Presupuesto para Traumatología: " + traumatologia);
    }
}
