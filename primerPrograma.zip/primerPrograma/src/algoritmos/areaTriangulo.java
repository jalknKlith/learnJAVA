
package algoritmos;

import java.util.Scanner; //Llamando la libreria scanner

public class areaTriangulo {

    public static void main(String[] args) {
        /* construir un algorimo que permita calcular
        el area de untriangulo, leer la base,
        la altura e imprima el resultado
        */
        float base, altura, area;
        Scanner leer = new Scanner(System.in);
        System.out.println("Ingrese la base del triangulo");
        base = leer.nextFloat(); //conversion implicita
        System.out.println("Ingrese la altura del triangulo");
        altura = (float) leer.nextFloat(); //conversion explicita
        area = base * altura / 2f;
        System.out.println("El area es: "+area);


    }
    
}
