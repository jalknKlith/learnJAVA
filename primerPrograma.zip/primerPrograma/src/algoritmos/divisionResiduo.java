package algoritmos;

import java.util.Scanner;

public class divisionResiduo {
    /* construir un algorimo que permita calcular
      el area de untriangulo, leer la base,
      la altura e imprima el resultado
      */
    Scanner leer = new Scanner(System.in);
    double num1, num2, residuo, cociente;
        System.out.println("Ingrese el primer numero");
        num1 = leer.nextDouble();
        System.out.println("Ingrese el segundo numero");
        num2 = leer.nextDouble();
        cociente = num1 / num2;
        residuo = num1 / num2;
        System.out.

}
