package algoritmos;

import java.util.Scanner;

public class IncrementoSalarial {

    public static void main(String[] args) {
	// Calcular el nuevo salario de un empleado, sabiendo que se tuvo un 
	// incremento del 25% sobre su salario anterior. 	
	// Declarar variables
        double salarioAnterior;
        double incremento;
        double nuevoSalario;

        // Crear un objeto Scanner para leer la entrada del usuario
        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario el salario anterior
        System.out.print("Ingrese el salario anterior: ");
        salarioAnterior = scanner.nextDouble();

        // Calcular el incremento del 25%
        incremento = salarioAnterior * 0.25;

        // Calcular el nuevo salario
        nuevoSalario = salarioAnterior + incremento;

        // Mostrar el nuevo salario
        System.out.println("El nuevo salario es: " + nuevoSalario);
    }
}
