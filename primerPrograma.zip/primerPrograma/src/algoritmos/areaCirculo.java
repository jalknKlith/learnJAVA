package algoritmos;

import java.util.Scanner;

public class areaCirculo {

    public static void main(String[] args){
        //Calcular el area de un circulo, leer el radio
        //e imprimir el area.
        Scanner leer = new Scanner(System.in);
        double radio, area;
        System.out.println("ingrese el radio");
        radio = leer.nextDouble();
        area = Math.PI * Math.pow(radio, 2);
        System.out.println("El area es: "+area);

    }
}
